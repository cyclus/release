// iso_vector.h
#if !defined(_ISOVECTOR_H)
#define _ISOVECTOR_H

/* -- Includes -- */
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include "logger.h"
#include "comp_map.h"
/* -- */


namespace cyclus {
/**
   shared pointer to another isovector
 */
class IsoVector;
typedef boost::shared_ptr<IsoVector> IsoVectorPtr;
/* -- */
} // namespace cyclus


/* -- Sensitive Includes -- */
#include "recipe_library.h"
/* -- */


namespace cyclus {

/* -- Typedefs -- */


/**
    @class IsoVector

    @section Introduction
    The IsoVector class is designed to intelligently manage a given
    isotopic composition in the form of a CompMap. Specifically, the IsoVector
    class defines all relevant operators to manage the decay, mixing, and
    separation of compositions.

    While a CompMap stores a normalized composition, an IsoVector provides
    methods to combine different compositions.

    @section Addition
    Addition of compositions is a specific case of the Mix() method. All
    values of a given composition are added to another at a ratio of 1:1. The
    finalized composition is then normalized.

    @section Subtraction
    Subtraction is not the reverse of addition, because it models the process
    of separation (and calls the Separate() method). Isotopic separation removes
    all isotopes at a given efficiency (if the efficiency is less than 1, some
    of those isotopes remain). Subtraction, accordingly, is separation with
    efficiency = 1. All isotopes are removed, and the remaining are normalized.

    @section Decay
    The IsoVector class manages the decay of CompMaps via the Decay(time)
    method. New children will have their parent and decay time set accordingly.
*/
class IsoVector : public boost::enable_shared_from_this<IsoVector> {
 public:
  /* --- Constructors and Destructors --- */
  /**
     default constructor
   */
  IsoVector();

  /**
     specialized constructor, assuming comp is already mass based.
     @param comp the composition to be copied into composition_
   */
  IsoVector(CompMapPtr comp);

  /**
     copy constructor
   */
  IsoVector(const IsoVector& other);

  /**
     default destructor, releases composition_
   */
  ~IsoVector();
  /* --- */

  /* --- Operators --- */
  /**
     assignment operator
   */
  IsoVector& operator=(IsoVector rhs);

  /**
     adds two compositions
     uses the Mix() function with a ratio of 1
   */
  IsoVector& operator+=(const IsoVector& rhs);

  /**
     subtracts two compositions
   */
  IsoVector& operator-=(const IsoVector& rhs);

  /**
     adds two compositions
     uses the Mix() function with a ratio of 1
   */
  const IsoVector operator+(const IsoVector& rhs) const;

  /**
     subtracts two compositions
   */
  const IsoVector operator-(const IsoVector& rhs) const;

  /**
     compares composition_ to rhs.comp()
   */
  bool operator==(const IsoVector& rhs) const;

  /**
     calls the == operator preceded by not (!)
   */
  bool operator!=(const IsoVector& rhs) const;
  /* --- */

  /* --- Instance Access --- */
  /**
     return the composition map
   */
  CompMapPtr comp() const;

  /**
     Return the mass fraction of an isotope in the composition
   */
  double MassFraction(Iso tope);

  /**
     returns the atom fraction of an isotope in the composition
   */
  double AtomFraction(Iso tope);

  /**
     calls composition_'s normalize
  */
  void normalize();

  /**
     validates the composition_, insuring all Isotopes numbers
     and fraction values comply
  */
  void Validate();

  /**
     resets all members to their initialized values
   */
  void reset();

  /**
     calls CompMap's printing functionality
   */
  void Print();

  /**
     records composition_ with the RecipeLibrary
   */
  void Record();

  /**
     computes the total mass fraction that this isovector has in
     common with other
     @param other the isovector to check for intersection
   */
  double IntersectionFraction(const IsoVector& other);

  /**
     calls compEqual on other.comp()
   */
  bool CompEquals(const IsoVector& other) const;

  /**
     calls equality operator on the values of composition_ and
     comp
   */
  bool CompEquals(const CompMapPtr comp) const;
  /* --- */

  /* --- Transformations --- */
  /**
     mixes this IsoVectors with another given ratio of this:other
     @param other the second IsoVector
     @param ratio the amount of c1 compared to c2
     @return a shared pointer to the resulting composition
   */
  void Mix(const IsoVector& other, double ratio);

  /**
     calls Mix() on values of p_c1 and p_c2
   */
  void Mix(const IsoVectorPtr& p_other, double ratio);

  /**
     separates an IsoVector from this one
     @param other the IsoVector to extract from this
     @param efficiency the effiency of the separation
     @return a shared pointer to the resulting composition
   */
  void Separate(const IsoVector& other, double efficiency);

  /**
     calls Separate() on values of p_c1 and p_c2
   */
  void Separate(const IsoVectorPtr& p_other, double efficiency);

  /**
     decays a composition for a given time, assumed to be in months

     this public function checks with the RecipeLibrary to see if comp is
     recorded as a decayable parent. if so, it will intelligently decay comp
     if a child has not already been decayed. if one has, a copy will be
     returned.
     @param time the decay time, in months
     @return a pointer to the result of this decay
   */
  virtual void Decay(int time);
  /* --- */

 private:
  /* --- Instance Management --- */
  /**
     the record level for all IsoVector instances
   */
  static LogLevel record_level_;

  /**
     a shared pointer to the CompMap managed by this IsoVector
   */
  CompMapPtr composition_;

  /**
     sets composition_ to comp
   */
  void SetComp(CompMapPtr comp);

  /**
     this private function uses the DecayHandler to decay a composition
     by a given time

     @param parent the composition to be decayed, a ptr recorded in the RecipeLibrary
     @param time the decay time, in months
     @return a pointer to the result of this decay
   */
  static CompMapPtr ExecuteDecay(CompMapPtr parent, int time);
  /* --- */
};
} // namespace cyclus
#endif
